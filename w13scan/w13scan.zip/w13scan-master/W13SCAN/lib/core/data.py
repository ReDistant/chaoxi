#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Time    : 2019/6/28 12:47 PM
# @Author  : w8ay
# @File    : data.py

from lib.core.log import LOGGER
from lib.core.datatype import AttribDict

logger = LOGGER
path = AttribDict()
KB = AttribDict()
conf = AttribDict()
