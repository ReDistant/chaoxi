## Contributors
boy-hack <https://github.com/boy-hack>
* for contributing core code

@LoRexxar'
* 给了很多修改意见

@Jinone
* 提供了用于寻找更多参数的提取思路

@longgo
* 提供json参数遍历算法

Go0p <https://github.com/Go0p>
* 加入struts系列检测插件

hackxx <https://github.com/hackxx>
* 贡献logout不扫描规则

Evilran <https://github.com/Evilran>
* 新增基于时间SQL注入，补充部分payload
* 新增未授权访问插件
* 修复部分bug

moonD4rk <https://github.com/moonD4rk>
* add xss payload output in attribute unquoted


## Links
- https://github.com/amcai/myscan 
    - @amcai的被动扫描器，部分内容在它的启发下完成
- https://github.com/qiyeboy/BaseProxy  代理框架基于它
- https://github.com/chaitin/xray  灵感来源，部分规则基于它
- https://github.com/knownsec/pocsuite3  代码框架模仿自它
